list.files(pattern = "csv$")

df = read.csv("Sports Supplements.csv")
head(df, 2)

colnames(df)[3] = "evidence"
# 정규표현식(regular expression)
# [^A-Za-z0-9]: 영문 대문자, 영문 소문자, 숫자를 제외한~
colnames(df) = gsub(pattern = "[^A-Za-z0-9]",
                    replacement = "_",
                    colnames(df))
colnames(df) = gsub(pattern = "_{2,}", # 언더바가 두 번 이상 반복
                    replacement = "_",
                    colnames(df))
colnames(df) = gsub(pattern = "^_|_$", # 첫 시작과 끝의 언더바
                    replacement = "", # 제거
                    colnames(df))
head(df, 2)
# colnames(df)[3] = "evidence"
table(df$evidence)
prop.table(table(df$evidence))
prop.table(table(df$evidence)) * 100
round(prop.table(table(df$evidence)) * 100, 1)

# 카이제곱 검정 or 비율검정

df = read.csv("fifa_eda_stats.csv")
head(df, 2)
table(df$Age)

df_sub = df[, c("ID", "Name", "Age", "Agility")]
head(df_sub, 2)

df_sub[, "age_30LT"] = ifelse(df_sub$Age < 30, 
                              yes = 1, no = 0)
# LT, LE, GT, GE
t.test(df_sub[df_sub$age_30LT == 1, "Agility"],
       df_sub[df_sub$age_30LT == 0, "Agility"])
# 나이가 30미만인 선수와 30이상인 선수의 "Agility"의 평균을
# 비교하기 위해서 독립 2표본 t검정을 실시함.
# 검정 결과 p-value가 매우 작기 때문에(< 2.2e-16)
# 유의수준 5%(0.05) 기준으로 검정 시 
# p-value가 0.05보다 작기 때문에 귀무가설을 기각하고
# 대립가설을 채택한다고 할 수 있다.
# 즉, 두 집단의 평균은 유의미하게 차이가 난다.

# 가끔 일어나는 실수
# ???: 평균 비교니까.... 평균을 넣으면 되겠지?ㅎ
t.test(mean(df_sub[df_sub$age_30LT == 1, "Agility"]),
       mean(df_sub[df_sub$age_30LT == 0, "Agility"]))
# 응 아님...😉

# 상관분석
# cor(), cor.test()

head(iris, 2)
result = aov(Sepal.Length ~ Species, data = iris)
summary(result) # ANOVA Table
# p-value가 작아서(<2e-16) 귀무가설을 기각하고
# 대립가설을 채택함.
# 적어도 하나 이상의 집단간 평균이 다름.

aggregate(data = iris, Sepal.Length ~ Species, FUN = "mean")
# FUN: function

TukeyHSD(result, "Species")
# p adj 확인.
# 모든 조합쌍에서 p-value가 0.05보다 작기 때문에
# 그 평균이 유의미하게 차이남

set.seed(123)
df_1 = data.frame(type = "A", v = rnorm(50, mean = 1, sd = 0.5))
df_2 = data.frame(type = "B", v = rnorm(50, mean = 1, sd = 0.2))
df_3 = data.frame(type = "C", v = rnorm(50, mean = 1, sd = 1))
df_4 = data.frame(type = "D", v = rnorm(50, mean = 1, sd = 1))
df_bind = rbind(df_1, df_2, df_3, df_4)
# v의 평균이 type별로 유의미하게 차이가 나는지 검정
result_2 = aov(formula = v ~ type, 
               data = df_bind[df_bind$type != "D", ])
summary(result_2)
# p-value가 0.0463으로 유의수준 5%(0.05)검정 시
# 유의수준보다 p-value가 더 작기 때문에 
# 귀무가설을 기각하고 대립가설을 채택함
# 즉, 집단간 평균이 차이가 남.

result_3 = aov(formula = v ~ type, 
               data = df_bind)
summary(result_3)
# p-value가 0.216으로 유의수준 5%(0.05)로 검정 시
# p-value가 유의수준 보다 크기 때문에 
# 귀무가설을 기각하지 못함. 즉, 집단간 평균이 같은 것이나 다름 없음.

# Random Forest + 변수중요도 평가
# LASSO 회귀




