1 + 1
1.01^200

getwd() # get working directory
# 주석(comment): 코드 실행에 영향을 미치지 않음

list.files()

df = read.csv("fifa_eda_stats.csv")
head(df, 2)
tail(df)

data("iris")
head(iris)
nrow(iris)

tail(iris, 1)
iris[150, ]
iris[nrow(iris), ]

install.packages("beepr")
library("beepr")
beep(2)

# install.packages("psych")
library("psych")
df = read.csv("fifa_eda_stats.csv")
head(describe(df), 2)

# install.packages("DataExplorer")
library("DataExplorer")
create_report(df)

# 정규성 검정 ####
# shapiro.test()

set.seed(123)
vec_n_1 = rnorm(n = 100, mean = 0, sd = 2)
vec_n_2 = rnorm(n = 100, mean = 2, sd = 4)
vec_u_1 = runif(n = 100) # 균등분포(uniform)

plot(vec_n_1)
hist(vec_n_1)
head(vec_n_1)

shapiro.test(vec_n_1)
# p-value = 0.9349
# (Shapiro-Wilk)정규성 검정 실시 결과
# p-value가 0.9349로 유의수준 5%기준으로 판단할 때
# 0.05보다 큰 값이 산출되었기 때문에 
# 귀무가설을 기각할 수 없다.
# 즉, 객체 "vec_n_1"에 있는 숫자의 분포는
# 정규분포와 다르다고 보기 어렵다. (→ 같다.)

hist(vec_u_1)
shapiro.test(vec_u_1)
# p-value = 0.000592
# (Shapiro-Wilk)정규성 검정 실시 결과
# p-value가 0.000592로 유의수준 5%기준으로 판단할 때
# 0.05보다 작은 값이 산출되었기 때문에 
# 귀무가설을 기각하고 대립가설을 채택한다.
# 즉, 객체 "vec_u_1"에 있는 숫자의 분포는
# 정규분포와 다르다고 할 수 있다.

